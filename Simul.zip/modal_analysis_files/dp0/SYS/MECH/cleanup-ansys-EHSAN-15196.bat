@echo off
set LOCALHOST=%COMPUTERNAME%
if /i "%LOCALHOST%"=="EHSAN" (taskkill /f /pid 17816)
if /i "%LOCALHOST%"=="EHSAN" (taskkill /f /pid 4748)
if /i "%LOCALHOST%"=="EHSAN" (taskkill /f /pid 10876)
if /i "%LOCALHOST%"=="EHSAN" (taskkill /f /pid 15196)

del /F cleanup-ansys-EHSAN-15196.bat
